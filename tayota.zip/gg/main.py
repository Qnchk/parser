def func(n):
    count=0
    for i in range(1,int((n)**0.5)+1):
        if(n%i==0 and abs(n//i-i)<=100):
            count+=1
    if(count>=3):
        return True
    else:
        return False
result=[]
for i in range(1000000,2000001):
    if(func(i)):
        result.append(i)
        print(i)

print(result)
